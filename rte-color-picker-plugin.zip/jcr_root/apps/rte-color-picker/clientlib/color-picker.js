(function ($, CUI) {
    var GROUP = "rte-color-picker",
        COLOR_PICKER_FEATURE = "colorPicker",
        TCP_POPOVER = "colorPickerPopOver",
        PICKER_NAME_IN_POPOVER = "color";
    
        const colors = [
            "#474747", 
            "#d04a02",
            "#e0301e",
            "#00ff00",
            "#ffff00",
            "#0000ff",
            "#000000"
        ]; 

    function isEmpty(value) {
        if (Array.isArray(value)) {
            return value.length === 0;
        } else if (value && typeof value === 'object') {
            return Object.keys(value).length === 0;
        } else if (typeof value === 'string') {
            return value.trim().length === 0;
        }
        return !value;
    }      

    function sendDataMessage(inputColor) {
        var message = {
            sender: GROUP,
            action: "submit",
            data: {}
        }, $dialog, color;
        $dialog = $(".cq-dialog");

        color = inputColor;
        if (color && color.indexOf("rgb") >= 0) {
            color = CUI.util.color.RGBAToHex(color);
        }
        message.data["color"] = color;
        parent.postMessage(JSON.stringify(message), "*");
    }

    function sendCancelMessage() {
        var message = {
            sender: GROUP,
            action: "cancel"
        };
        parent.postMessage(JSON.stringify(message), "*");
    }

    addPluginToDefaultUISettings();
    addColorPickerPalette();

    var ColorPickerPopOver = new Class({
        extend: CUI.rte.ui.cui.AbstractDialog,

        toString: "ColorPickerPopOver",

        initialize: function (config) {
            this.exec = config.execute;
        },

        getDataType: function () {
            return TCP_POPOVER;
        }
    });

    var TouchUIColorPickerPlugin = new Class({
        toString: "TouchUIColorPickerPlugin",

        extend: CUI.rte.plugins.Plugin,

        pickerUI: null,

        getFeatures: function () {
            return [COLOR_PICKER_FEATURE];
        },

        initializeUI: function (tbGenerator) {
            var plg = CUI.rte.plugins;

            if (!this.isFeatureEnabled(COLOR_PICKER_FEATURE)) {
                return;
            }

            this.pickerUI = tbGenerator.createElement(COLOR_PICKER_FEATURE, this, false, { title: "Color Picker" });
            tbGenerator.addElement(GROUP, plg.Plugin.SORT_FORMAT, this.pickerUI, 10);

            var groupFeature = GROUP + "#" + COLOR_PICKER_FEATURE;
            tbGenerator.registerIcon(groupFeature, "textColor");
        },

        execute: function (id, value, envOptions) {
            if (!isValidSelection()) {
                return;
            }

            var context = envOptions.editContext,
                selection = CUI.rte.Selection.createProcessingSelection(context),
                ek = this.editorKernel,
                startNode = selection.startNode;
            if ((selection.startOffset === startNode.length) && (startNode != selection.endNode)) {
                startNode = startNode.nextSibling;
            }

            var tag = CUI.rte.Common.getTagInPath(context, startNode, "span"), plugin = this, dialog,
                color = $(tag).css("color"),
                dm = ek.getDialogManager(),
                $container = CUI.rte.UIUtils.getUIContainer($(context.root)),
                propConfig = {
                    'parameters': {
                        'command': this.pluginId + '#' + COLOR_PICKER_FEATURE
                    }
                };

            let endColor = $(CUI.rte.Common.getTagInPath(context, selection.endNode, "span")).css("color");//.attr('class');
            
            if (color && (color == endColor)) {
                color = CUI.util.color.RGBAToHex(color);
            }else{
                color=null;
            } 

            dialog = new ColorPickerPopOver();
            dialog.attach(propConfig, $container, this.editorKernel);
            dialog.$dialog.css("-webkit-transform", "scale(0.9)").css("-webkit-transform-origin", "0 0")
                .css("-moz-transform", "scale(0.9)").css("-moz-transform-origin", "0px 0px");

            this.colorPickerPopOver = dialog;

            dm.show(dialog);

            registerReceiveDataListener(receiveMessage);

            const squares = document.querySelectorAll('.square');

            squares.forEach(s => s.classList.remove('selected'));
            if (colors.indexOf(color)!=-1) {
                squares[colors.indexOf(color)+1].classList.add('selected');
            }

            squares.forEach(square => {
                square.addEventListener('click', (event) => {
                    squares.forEach(s => s.classList.remove('selected'));
                    square.classList.add('selected');
                    sendDataMessage(event.target.style.backgroundColor);

                });
            });

            $('.cq-RichText-editable').on('click', checkAndClose);

            function checkAndClose() {
                if ($('coral-popover').hasClass('rte-dialog--colorPickerPopOver') && $('coral-popover').hasClass('is-open')) {
                    sendCancelMessage();
                }
                $('.cq-RichText-editable').off('click', checkAndClose);
            }

            function isValidSelection() {
                var winSel = window.getSelection();
                return winSel && winSel.rangeCount == 1 && winSel.getRangeAt(0).toString().length > 0;
            }

            function removeReceiveDataListener(handler) {
                if (window.removeEventListener) {
                    window.removeEventListener("message", handler);
                } else if (window.detachEvent) {
                    window.detachEvent("onmessage", handler);
                }
            }

            function registerReceiveDataListener(handler) {
                if (window.addEventListener) {
                    window.addEventListener("message", handler, false);
                } else if (window.attachEvent) {
                    window.attachEvent("onmessage", handler);
                }
            }

            function receiveMessage(event) {
                if (isEmpty(event.data)) {
                    return;
                }

                var message = JSON.parse(event.data),
                    action;

                if (!message || message.sender !== GROUP) {
                    return;
                }

                action = message.action;

                if (action === "submit") {
                    if (!isEmpty(message.data)) {
                        ek.relayCmd(id, message.data);
                    }
                } else if (action === "remove") {
                    ek.relayCmd(id);
                    plugin.colorPickerPopOver = null;
                } else if (action === "cancel") {
                    plugin.colorPickerPopOver = null;
                }

                dialog.hide();

                removeReceiveDataListener(receiveMessage);
            }
        },

        //to mark the icon selected/deselected
        updateState: function (selDef) {
            var hasUC = this.editorKernel.queryState(COLOR_PICKER_FEATURE, selDef);

            if (this.pickerUI != null) {
                this.pickerUI.setSelected(hasUC);
            }
        }
    });

    CUI.rte.plugins.PluginRegistry.register(GROUP, TouchUIColorPickerPlugin);

    var TouchUIColorPickerCmd = new Class({
        toString: "TouchUIColorPickerCmd",

        extend: CUI.rte.commands.Command,

        isCommand: function (cmdStr) {
            return (cmdStr.toLowerCase() == COLOR_PICKER_FEATURE);
        },

        getProcessingOptions: function () {
            var cmd = CUI.rte.commands.Command;
            return cmd.PO_SELECTION | cmd.PO_BOOKMARK | cmd.PO_NODELIST;
        },

        _getTagObject: function (color) {
            return {
                "tag": "span",
                "attributes": {
                    "style" : "color:" + color
                }
            };
        },

        execute: function (execDef) {
            var color = execDef.value ? execDef.value[PICKER_NAME_IN_POPOVER] : undefined,
                selection = execDef.selection,
                nodeList = execDef.nodeList;

            if (!selection || !nodeList) {
                return;
            }

            var common = CUI.rte.Common,
                context = execDef.editContext,
                tagObj = this._getTagObject(color);

            //if no color value passed, assume delete and remove color
            if (isEmpty(color)) {
                nodeList.removeNodesByTag(execDef.editContext, tagObj.tag, undefined, true);
                return;
            }

            var tags = common.getTagInPath(context, selection.startNode, tagObj.tag);

            //remove existing color before adding new color
            if (tags != null) {
                nodeList.removeNodesByTag(execDef.editContext, tagObj.tag, undefined, true);
                nodeList.commonAncestor = nodeList.nodes[0].dom.parentNode;
            }
            nodeList.surround(execDef.editContext, tagObj.tag, tagObj.attributes);

        }
    });

    CUI.rte.commands.CommandRegistry.register(COLOR_PICKER_FEATURE, TouchUIColorPickerCmd);

    function addPluginToDefaultUISettings() {
        var toolbar = CUI.rte.ui.cui.DEFAULT_UI_SETTINGS.inline.toolbar;
        toolbar.splice(3, 0, GROUP + "#" + COLOR_PICKER_FEATURE);
        toolbar = CUI.rte.ui.cui.DEFAULT_UI_SETTINGS.fullscreen.toolbar;
        toolbar.splice(3, 0, GROUP + "#" + COLOR_PICKER_FEATURE);
    }

    function addColorPickerPalette() {             
        let html = '<div class="palette"><span class="square no-color"></span>';        
        colors.forEach(color => {
            html += `<span style="background-color:${color}" class="square"></span>`;
        });
        html += '</div>';        

        if (typeof CUI.rte.Templates === 'undefined') {
            CUI.rte.Templates = {};
        }
        if (typeof CUI.rte.Templates === 'undefined') {
            CUI.rte.templates = {};
        }
        CUI.rte.templates['dlg-' + TCP_POPOVER] = CUI.rte.Templates['dlg-' + TCP_POPOVER] = Handlebars.compile(html);
    }
}(jQuery, window.CUI, jQuery(document)));